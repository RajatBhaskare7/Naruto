// eslint-disable-next-line
export { default } from '../../build/core';
// needed here for Angular
