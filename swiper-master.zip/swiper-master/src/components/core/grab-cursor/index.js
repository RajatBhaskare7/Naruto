import setGrabCursor from './setGrabCursor';
import unsetGrabCursor from './unsetGrabCursor';

export default {
  setGrabCursor,
  unsetGrabCursor,
};
